/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { OfficialHeroBanner } from './components/OfficialHeroBanner';
import { HeroScrub } from './components/ui/hero-scrub';
import { LineupSection } from './components/LineupSection';
import { ScoutBobberFeatures } from './components/ScoutBobberFeatures';
import { AudioEngineRev } from './components/AudioEngineRev';
import { CustomizerModal } from './components/CustomizerModal';
import { DealerLocatorModal } from './components/DealerLocatorModal';
import { EmailSignupModal } from './components/EmailSignupModal';
import { Footer } from './components/Footer';
import { MOTORCYCLE_LINEUP, MotorcycleModel } from './data/motorcycles';
import { Sparkles, ArrowDown } from 'lucide-react';

export default function App() {
  const [selectedModel, setSelectedModel] = useState<MotorcycleModel | null>(MOTORCYCLE_LINEUP[0]);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [isDealerModalOpen, setIsDealerModalOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [showScrubHero, setShowScrubHero] = useState(false);

  const handleOpenCustomizer = (model: MotorcycleModel) => {
    setSelectedModel(model);
    setIsCustomizerOpen(true);
  };

  const handleOpenTestRide = (model?: MotorcycleModel) => {
    if (model) setSelectedModel(model);
    setIsDealerModalOpen(true);
  };

  const handleExploreLineup = () => {
    const el = document.getElementById('lineup');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f5] flex flex-col font-primary selection:bg-[#ff2c2c] selection:text-black">
      {/* 1. Official Header & Navigation Bar */}
      <Header
        onOpenDealerModal={() => setIsDealerModalOpen(true)}
        onOpenEmailModal={() => setIsEmailModalOpen(true)}
        onOpenCartModal={() => setIsEmailModalOpen(true)}
        onSelectModel={(id) => {
          const m = MOTORCYCLE_LINEUP.find((item) => item.id === id);
          if (m) setSelectedModel(m);
        }}
      />

      {/* Hero Experience Mode Toggle Bar - Editorial Style */}
      <div className="bg-[#0e0e0e] border-b border-white/5 py-2.5 px-6 lg:px-10 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2 text-white/80">
            <span className="w-2 h-2 rounded-full bg-[#ff2c2c] animate-pulse" />
            <span className="font-bold uppercase tracking-[0.2em] text-[10px]">
              2025 INDIAN SCOUT BOBBER SHOWCASE
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-[10px] text-white/40 font-medium uppercase tracking-wider hidden sm:inline">
              Display Mode:
            </span>
            <button
              onClick={() => setShowScrubHero(false)}
              className={`px-3 py-1 rounded-sm text-[10px] font-bold uppercase tracking-wider transition-all ${
                !showScrubHero
                  ? 'bg-[#ff2c2c] text-black shadow-md'
                  : 'bg-[#161616] text-white/50 hover:text-white'
              }`}
            >
              Editorial Hero
            </button>
            <button
              onClick={() => setShowScrubHero(true)}
              className={`px-3 py-1 rounded-sm text-[10px] font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 ${
                showScrubHero
                  ? 'bg-[#ff2c2c] text-black shadow-md'
                  : 'bg-[#161616] text-white/50 hover:text-white'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span>Cinematic Scroll Scrub</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Hero Section: Editorial Hero Reel or 3D Scroll Scrub */}
      {showScrubHero ? (
        <div className="relative bg-[#0a0a0a]">
          <div className="bg-[#141414] text-white text-center py-2 text-[10px] font-bold uppercase tracking-[0.25em] border-b border-white/5 flex items-center justify-center gap-2">
            <ArrowDown className="w-3.5 h-3.5 animate-bounce text-[#ff2c2c]" />
            <span>Scroll down to scrub through the cinematic frames</span>
          </div>
          <HeroScrub
            frameCount={300}
            frameUrl={(i) =>
              `https://raw.githubusercontent.com/duthiljean/ferrari-hero-demo/main/${String(i + 1).padStart(4, "0")}.webp`
            }
            titleTop="INDIAN"
            titleBottom="SCOUT BOBBER"
            accentHex="#ff2c2c"
          />
        </div>
      ) : (
        <OfficialHeroBanner
          onExploreLineup={handleExploreLineup}
          onOpenTestRide={() => handleOpenTestRide(selectedModel || undefined)}
        />
      )}

      {/* 3. Official Lineup Showcase */}
      <LineupSection
        selectedModelId={selectedModel?.id}
        onOpenCustomizer={handleOpenCustomizer}
        onOpenTestRide={handleOpenTestRide}
      />

      {/* 4. Scout Bobber Engineering & Heritage Deep Dive */}
      <ScoutBobberFeatures />

      {/* 5. Acoustic American V-Twin Rev Simulator */}
      <AudioEngineRev />

      {/* 6. Quick Action / Pre-Order Banner (Editorial Style) */}
      <section className="w-full bg-[#ff2c2c] text-black py-12 px-6 lg:px-10 shadow-2xl">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.25em] text-black/80 block">
              READY TO OWN AN AMERICAN ICON?
            </span>
            <h3 className="text-2xl md:text-4xl font-black uppercase italic font-display text-black mt-0.5">
              BUILD YOUR CUSTOM SCOUT BOBBER TODAY
            </h3>
            <p className="text-xs text-black/80 mt-1 max-w-xl font-medium">
              Customize factory colors, high-flow exhausts, ape hangers, and receive an instant quote from your local dealer.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => handleOpenCustomizer(selectedModel || MOTORCYCLE_LINEUP[0])}
              className="bg-black hover:bg-white hover:text-black text-white px-6 py-3 rounded-sm text-xs font-black uppercase tracking-wider transition-all shadow-xl"
            >
              LAUNCH CONFIGURATOR
            </button>
            <button
              onClick={() => handleOpenTestRide(selectedModel || undefined)}
              className="border-2 border-black hover:bg-black hover:text-white text-black px-6 py-3 rounded-sm text-xs font-black uppercase tracking-wider transition-all"
            >
              FIND LOCAL INVENTORY
            </button>
          </div>
        </div>
      </section>

      {/* 7. Comprehensive Footer */}
      <Footer />

      {/* Modals */}
      <CustomizerModal
        model={selectedModel}
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        onSelectTestRide={handleOpenTestRide}
      />

      <DealerLocatorModal
        isOpen={isDealerModalOpen}
        onClose={() => setIsDealerModalOpen(false)}
        preSelectedModel={selectedModel}
      />

      <EmailSignupModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
      />
    </div>
  );
}
