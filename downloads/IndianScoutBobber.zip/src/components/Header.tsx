import React, { useState } from 'react';
import { Search, MapPin, User, ShoppingCart, Menu, X, ChevronRight } from 'lucide-react';

interface HeaderProps {
  onOpenDealerModal: () => void;
  onOpenEmailModal: () => void;
  onOpenCartModal: () => void;
  onSelectModel: (modelId: string) => void;
}

export function Header({ onOpenDealerModal, onOpenEmailModal, onOpenCartModal, onSelectModel }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const quickSearchSuggestions = [
    { title: 'Scout Bobber 2025', id: 'scout-bobber-2025', category: 'Motorcycles' },
    { title: '101 Scout Performance', id: 'scout-101', category: 'Motorcycles' },
    { title: 'Scout Bobber Twenty', id: 'scout-bobber-twenty', category: 'Motorcycles' },
    { title: 'Chief Vintage 125th Anniversary', id: 'chief-vintage-125', category: 'Motorcycles' },
    { title: 'Scout Sixty Bobber', id: 'scout-sixty-bobber', category: 'Motorcycles' },
    { title: 'Stage 1 2-into-1 Full Exhaust', id: 'acc-exhaust', category: 'Accessories' },
  ];

  const filteredSuggestions = searchQuery.trim() === ''
    ? quickSearchSuggestions.slice(0, 4)
    : quickSearchSuggestions.filter(item => item.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <header className="w-full z-50 sticky top-0 bg-[#0a0a0a]/90 backdrop-blur-md border-b border-white/5 transition-all">
      {/* Top Editorial Crimson Bar */}
      <div className="bg-[#ff2c2c] text-black px-6 lg:px-10 py-1.5 text-xs font-semibold flex items-center justify-between transition-colors">
        {/* Left: Indian Motorcycle Badge & Script */}
        <div className="flex items-center space-x-3">
          <a href="#hero" className="flex items-center space-x-2 group">
            <div className="w-6 h-6 bg-black text-white rounded-full flex items-center justify-center font-bold text-xs italic shadow-sm group-hover:scale-105 transition-transform">
              I
            </div>
            <div className="flex items-center space-x-2">
              <span className="font-black tracking-widest text-[12px] uppercase font-display leading-none text-black">
                INDIAN MOTORCYCLE
              </span>
              <span className="hidden sm:inline text-[9px] tracking-[0.2em] text-black/80 font-bold uppercase">
                • EST. 1901
              </span>
            </div>
          </a>
        </div>

        {/* Center: Search Box */}
        <div className="hidden md:flex flex-1 max-w-sm mx-6 relative">
          <div className="relative w-full">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchOpen(true)}
              onBlur={() => setTimeout(() => setIsSearchOpen(false), 250)}
              placeholder="Search Scout models, specs, gear..."
              className="w-full bg-black/90 text-white placeholder:text-white/50 rounded-sm py-1 pl-3 pr-7 text-[11px] focus:outline-none focus:ring-1 focus:ring-black font-normal"
            />
            <Search className="w-3.5 h-3.5 text-white/70 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Quick search dropdown */}
          {isSearchOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[#141414] border border-white/10 rounded-sm shadow-2xl py-2 z-50">
              <div className="px-3 py-1 text-[9px] uppercase font-bold text-neutral-400 border-b border-white/5">
                Popular Searches
              </div>
              {filteredSuggestions.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (item.id.startsWith('scout-') || item.id.startsWith('chief-')) {
                      onSelectModel(item.id);
                      const el = document.getElementById('lineup');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="w-full px-3 py-1.5 text-left text-xs text-white hover:bg-[#ff2c2c] hover:text-black flex items-center justify-between group transition-colors"
                >
                  <span className="font-medium">{item.title}</span>
                  <span className="text-[10px] text-white/50 group-hover:text-black/80">{item.category}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Tools: Find Dealer, Log In, Cart */}
        <div className="flex items-center space-x-4 lg:space-x-6 text-[11px] font-bold tracking-wider uppercase text-black">
          <button
            onClick={onOpenDealerModal}
            className="flex items-center space-x-1 hover:text-white transition-colors"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Find Dealer</span>
          </button>
          <button
            onClick={onOpenEmailModal}
            className="flex items-center space-x-1 hover:text-white transition-colors"
          >
            <User className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Garage</span>
          </button>
          <button
            onClick={onOpenCartModal}
            className="flex items-center space-x-1 hover:text-white transition-colors relative"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Cart</span>
            <span className="bg-black text-[#ff2c2c] text-[9px] font-bold rounded-full h-3.5 w-3.5 flex items-center justify-center">
              0
            </span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar - Editorial Style */}
      <nav className="px-6 lg:px-10 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <a href="#hero" className="flex items-center gap-2.5">
            <div className="w-7 h-7 bg-[#ff2c2c] rounded-full flex items-center justify-center font-bold text-black text-xs italic shadow-md">
              I
            </div>
            <span className="font-bold uppercase tracking-widest text-sm text-[#f5f5f5]">
              Indian Motorcycle
            </span>
          </a>

          {/* Desktop Nav Items with Editorial Spacing & Tracking */}
          <div className="hidden lg:flex items-center gap-8 text-[11px] uppercase tracking-[0.2em] font-medium text-white/70">
            <a
              href="#lineup"
              className="hover:text-[#ff2c2c] transition-colors py-1"
            >
              Motorcycles
            </a>
            <a
              href="#heritage"
              className="hover:text-[#ff2c2c] transition-colors py-1"
            >
              Heritage
            </a>
            <a
              href="#customizer"
              className="hover:text-[#ff2c2c] transition-colors py-1"
            >
              Build & Customizer
            </a>
            <a
              href="#audio-rev"
              className="hover:text-[#ff2c2c] transition-colors py-1"
            >
              Sound Lab
            </a>
            <button
              onClick={onOpenDealerModal}
              className="hover:text-[#ff2c2c] transition-colors py-1 uppercase"
            >
              Experience
            </button>
            <a
              href="#footer"
              className="hover:text-[#ff2c2c] transition-colors py-1"
            >
              Owners
            </a>
          </div>
        </div>

        {/* Quick CTA button on right */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href="#lineup"
            className="border border-white/20 text-white hover:border-[#ff2c2c] hover:text-[#ff2c2c] px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all"
          >
            Explore Lineup
          </a>
          <button
            onClick={onOpenDealerModal}
            className="bg-white text-black hover:bg-[#ff2c2c] hover:text-black px-4 py-2 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all shadow-sm"
          >
            Build Yours
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-white hover:text-[#ff2c2c] focus:outline-none"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* Mobile menu expanded */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-6 pt-2 pb-4 border-t border-white/5 flex flex-col space-y-3 bg-[#0a0a0a] animate-fadeIn">
          <a
            href="#lineup"
            onClick={() => setMobileMenuOpen(false)}
            className="text-white font-bold uppercase text-xs tracking-wider py-2 px-2 hover:bg-white/5 rounded"
          >
            Motorcycles & Scout Lineup
          </a>
          <a
            href="#heritage"
            onClick={() => setMobileMenuOpen(false)}
            className="text-white font-bold uppercase text-xs tracking-wider py-2 px-2 hover:bg-white/5 rounded"
          >
            Scout Bobber Heritage
          </a>
          <a
            href="#customizer"
            onClick={() => setMobileMenuOpen(false)}
            className="text-white font-bold uppercase text-xs tracking-wider py-2 px-2 hover:bg-white/5 rounded"
          >
            Build & Customizer
          </a>
          <a
            href="#audio-rev"
            onClick={() => setMobileMenuOpen(false)}
            className="text-white font-bold uppercase text-xs tracking-wider py-2 px-2 hover:bg-white/5 rounded"
          >
            V-Twin Sound Lab
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenDealerModal();
            }}
            className="text-left text-white font-bold uppercase text-xs tracking-wider py-2 px-2 hover:bg-white/5 rounded flex items-center justify-between"
          >
            <span>Find a Dealer & Test Ride</span>
            <ChevronRight className="w-4 h-4 text-[#ff2c2c]" />
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenEmailModal();
            }}
            className="w-full bg-[#ff2c2c] text-black text-center py-2.5 font-bold uppercase tracking-wider text-xs rounded-sm"
          >
            Email Offers & Updates
          </button>
        </div>
      )}

      {/* Floating Vertical "EMAIL SIGNUP" Tab on right side */}
      <button
        onClick={onOpenEmailModal}
        className="fixed right-0 top-1/2 -translate-y-1/2 z-40 bg-[#ff2c2c] hover:bg-white text-black px-2 py-4 shadow-2xl flex flex-col items-center justify-center rounded-l cursor-pointer transition-transform hover:-translate-x-1"
        style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }}
        title="Get Indian Motorcycle exclusive offers & news"
      >
        <span className="text-[10px] font-black uppercase tracking-[0.25em] flex items-center gap-2">
          <span>EMAIL SIGNUP</span>
          <span className="rotate-90 text-[9px]">▲</span>
        </span>
      </button>
    </header>
  );
}
